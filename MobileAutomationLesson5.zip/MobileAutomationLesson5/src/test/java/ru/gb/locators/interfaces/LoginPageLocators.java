package ru.gb.locators.interfaces;

import org.openqa.selenium.By;

public interface LoginPageLocators {

    By loginButton();
    By loginErrorText();
}
