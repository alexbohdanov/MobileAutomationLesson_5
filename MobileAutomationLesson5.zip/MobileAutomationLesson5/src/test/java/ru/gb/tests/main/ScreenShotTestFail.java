package ru.gb.tests.main;

public class ScreenShotTestFail extends ru.gb.base.BaseTest {


}
