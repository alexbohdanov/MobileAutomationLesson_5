package ru.gb.tests.login;


import org.testng.annotations.Test;




public class CheckFailErrorTextTest extends ru.gb.base.BaseTest {

    @Test
    public void checkEmptyEmail() throws Exception {


        openApp()
                .clickLoginMenuButton()
                .clickLoginButton()
                .checkLoginErrorText("Please enter a valid email address");

    }
}