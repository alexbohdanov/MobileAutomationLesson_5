package ru.gb.tests.main;

import org.testng.annotations.Test;

public class ScreenShotTest extends ru.gb.base.BaseTest {

    @Test
    public void checkMainPageScreen(){
        openApp()
                .checkScreenshot();
    }
}
